ix.command.Add("CharSetHead", {
	description = "Changes head of the character.",
	arguments = {
		ix.type.character,
		ix.type.string
	},
    adminOnly = true,
	OnRun = function(self, client,character, modelpath)

        character:SetHeadmodel(modelpath)

	end
})
ix.command.Add("CharSetBodymodel", {
	description = "Changes current bodymodel. ",
	arguments = {
		ix.type.character,
		ix.type.string
	},
    adminOnly = true,
	OnRun = function(self,client, character, modelpath)
        
        character:SetBodymodel(modelpath)

	end
})
