local aviableHeads = {
    ["models/lazarusroleplay/heads/female_african.mdl"] = true,
    ["models/lazarusroleplay/heads/female_asian.mdl"] = true,
    ["models/lazarusroleplay/heads/female_caucasian.mdl"] = true,
    ["models/lazarusroleplay/heads/female_hispanic.mdl"] = true,
    ["models/lazarusroleplay/heads/male_african.mdl"] = true,
    ["models/lazarusroleplay/heads/male_asian.mdl"] = true,
    ["models/lazarusroleplay/heads/male_caucasian.mdl"] = true,
    ["models/lazarusroleplay/heads/male_hispanic.mdl"] = true

}


do
	for k,_ in pairs(aviableHeads) do
		util.PrecacheModel(k)
	end

end
ix.char.RegisterVar("model", {
		field = "model",
		fieldType = ix.type.string,
		default = "models/player/heads/male_caucasian.mdl",
		index = 10,
		OnSet = function(character, value)
			local client = character:GetPlayer()

            //client:SetModel(value)

			character.vars.model = value
		end,
		OnGet = function(character, default)
			
			return character.vars.model or default
		end,
		OnDisplay = function(self, container, payload)
			
		end,
		OnValidate = function(self, value, payload, client)

		end,
		OnAdjust = function(self, client, data, value, newData)

		end,
		ShouldDisplay = function(self, container, payload)
            return false
		end
	})

ix.char.RegisterVar("bodymodel", {
		field = "bodymodel",
		fieldType = ix.type.string,
		default = "models/dizcordum/males/farmer.mdl",
		index = 10,
		OnSet = function(character, value)
			local client = character:GetPlayer()
            
            /*


            if(IsValid(client))then
			    if(client.body)then
                    client.body:SetModel(value)
                end
            end
            //client:SetModel(value)*/

			character.vars.bodymodel = value
            client:LoadBody()
		end,
		
		OnGet = function(character, default)
			if(!character.vars.bodymodel)then
				local isFemale = string.find(character:GetHeadmodel(),"female")
				local model = ""
				if(isFemale)then
					return "models/thespireroleplay/humans/group100/female.mdl"
				else
					return "models/thespireroleplay/humans/group100/male.mdl"
				end
			end
			return character.vars.bodymodel or default
		end,
		OnDisplay = function(self, container, payload)
			
		end,
		OnValidate = function(self, value, payload, client)

		end,
		OnAdjust = function(self, client, data, value, newData)

		end,
		ShouldDisplay = function(self, container, payload)
            return false
		end
	})

ix.char.RegisterVar("headmodel", {
		field = "headmodel",
		fieldType = ix.type.string,
		default = "models/lazarusroleplay/heads/male_african.mdl",
		index = 3,
		OnSet = function(character,value)
			local client = character:GetPlayer()
            
            /*
            if(IsValid(client))then
			    if(client.head)then
                    client.head:SetModel(value)
                end
            end*/

			character.vars.headmodel = value
            client:LoadBody()
		end,
		OnGet = function(character, default)
			return character.vars.headmodel or default
		end,
		OnDisplay = function(self, container, payload)
			payload:Set("headmodel",self.default)
            local charmenu = container:GetParent():GetParent()
            charmenu.factionModel:SetModel("models/lazarusroleplay/heads/male_african.mdl")
            charmenu.descriptionModel:SetModel("models/lazarusroleplay/heads/male_african.mdl")
            charmenu.attributesModel:SetModel("models/lazarusroleplay/heads/male_african.mdl")

			//print(PrintTable(charmenu.descriptionModel.Entity:GetColor()))

			local scroll = container:Add("DScrollPanel")
			scroll:Dock(TOP) -- TODO: don't fill so we can allow other panels
            scroll:SetHeight(container:GetTall()*.5)
			scroll.Paint = function(panel, width, height)
				derma.SkinFunc("DrawImportantBackground", 0, 0, width, height, Color(255, 255, 255, 25))
			end

			local layout = scroll:Add("DIconLayout")
			layout:Dock(FILL)
			layout:SetSpaceX(2)
			layout:SetSpaceY(2)


				for k, v in pairs(aviableHeads) do
					local icon = layout:Add("SpawnIcon")
					icon:SetSize(128, 256)
					icon:InvalidateLayout(true)
					icon.DoClick = function(this)
                        charmenu.factionModel:SetModel(k)
                        charmenu.descriptionModel:SetModel(k)
                        charmenu.attributesModel:SetModel(k)
						payload:Set("headmodel", k)

					end
					icon.PaintOver = function(this, w, h)
						if (payload.headmodel == k) then
							local color = ix.config.Get("color", color_white)

							surface.SetDrawColor(color.r, color.g, color.b, 200)

							for i = 1, 3 do
								local i2 = i * 2
								surface.DrawOutlinedRect(i, i, w - i2, h - i2)
							end
						end
					end
					icon:SetModel(k)
				end
				//scroll:SizeToContentsY()

			return scroll
		end,
		OnValidate = function(self, value, payload, client)

			if (!payload.headmodel) then
				return false, "needHeadModel"
			end
		end,
		OnAdjust = function(self, client, data, value, newData)
            
		end,
		ShouldDisplay = function(self, container, payload)
			return true
		end
	})
    //Head, Head Skin, Head Color, Head Bodygroup, Body. Juste this
ix.char.RegisterVar("hairbodygroup", {
		field = "hairbodygroup",
		fieldType = ix.type.number,
		default = 0,
		index = 4,
		OnSet = function(character, value)
			local client = character:GetPlayer()

			if (IsValid(client) and client:GetCharacter() == character) then
				//client:ReloadBody()
			end

			character.vars.hairbodygroup = value
		end,
		OnGet = function(character, default)
			return character.vars.hairbodygroup or default
		end,
		OnDisplay = function(self, container, payload)
			local charmenu = container:GetParent():GetParent()
			local height = draw.GetFontHeight("ixMenuButtonFont")
			local grid = container:Add("DGrid")
			grid:Dock(TOP) 
			grid:SetCols(2)
			grid:SetColWide(container:GetWide()/2)
			grid:SetRowHeight(height)

			local minus = vgui.Create("ixMenuButton")
			minus:SetContentAlignment(5)
			minus:SetText("-")
			minus:SetWidth(container:GetWide()/2)
			minus:SetHeight(height)
			minus.DoClick = function()
				local modelEnt = charmenu.descriptionModel.Entity
				local hairBodygroupID = modelEnt:FindBodygroupByName("hair")
				local curValue = modelEnt:GetBodygroup(hairBodygroupID)
				local newValue = math.Clamp(curValue-1,0,modelEnt:GetBodygroupCount(hairBodygroupID)+1)
				//print("id:",hairBodygroupID,"cur:",curValue,"shouldbe:",math.Clamp(curValue+1,0,modelEnt:GetBodygroupCount(hairBodygroupID)-1))
				modelEnt:SetBodygroup(hairBodygroupID,newValue)
				payload:Set("hairbodygroup", newValue)

			end
			grid:AddItem(minus)

			local plus = vgui.Create("ixMenuButton")
			plus:SetContentAlignment(5)
			plus:SetText("+")
			plus:SetWidth(container:GetWide()/2)
			plus:SetHeight(height)
			plus.DoClick = function()
				//print("dsad")
				//PrintTable(charmenu.descriptionModel.Entity:GetBodyGroups())
				local modelEnt = charmenu.descriptionModel.Entity
				local hairBodygroupID = modelEnt:FindBodygroupByName("hair")
				local curValue = modelEnt:GetBodygroup(hairBodygroupID)
				//print("id:",hairBodygroupID,"cur:",curValue,"shouldbe:",math.Clamp(curValue+1,0,modelEnt:GetBodygroupCount(hairBodygroupID)-1))
				local newValue = math.Clamp(curValue+1,0,modelEnt:GetBodygroupCount(hairBodygroupID)-1)
				modelEnt:SetBodygroup(hairBodygroupID,newValue)
				payload:Set("hairbodygroup", newValue)
			end
			grid:AddItem(plus)







			return grid
		end,
		OnValidate = function(self, value, payload, client)


		end,
		OnAdjust = function(self, client, data, value, newData)
            
		end,
		ShouldDisplay = function(self, container, payload)
			return true
		end
	})

ix.char.RegisterVar("facialhairbodygroup", {
		field = "facialhairbodygroup",
		fieldType = ix.type.number,
		default = 0,
		index = 5,
		OnSet = function(character, value)
			local client = character:GetPlayer()

			if (IsValid(client) and client:GetCharacter() == character) then
				//client:ReloadBody()
			end

			character.vars.facialhairbodygroup = value
		end,
		OnGet = function(character, default)
			return character.vars.facialhairbodygroup or default
		end,
		OnDisplay = function(self, container, payload)

			payload:Set("facialhairbodygroup", 0)
			local charmenu = container:GetParent():GetParent()
			local height = draw.GetFontHeight("ixMenuButtonFont")
			local grid = container:Add("DGrid")
			grid:Dock(TOP) 
			grid:SetCols(2)
			grid:SetColWide(container:GetWide()/2)
			grid:SetRowHeight(height)

			local minus = vgui.Create("ixMenuButton")
			minus:SetContentAlignment(5)
			minus:SetText("-")
			minus:SetWidth(container:GetWide()/2)
			minus:SetHeight(height)
			minus.DoClick = function()
				local modelEnt = charmenu.descriptionModel.Entity
				local hairBodygroupID = modelEnt:FindBodygroupByName("facialhair")
				local curValue = modelEnt:GetBodygroup(hairBodygroupID)
				local newValue = math.Clamp(curValue-1,0,modelEnt:GetBodygroupCount(hairBodygroupID)-1)
				modelEnt:SetBodygroup(hairBodygroupID,newValue)
				payload:Set("facialhairbodygroup", newValue)
			end
			grid:AddItem(minus)

			local plus = vgui.Create("ixMenuButton")
			plus:SetContentAlignment(5)
			plus:SetText("+")
			plus.DoClick = function()
				local modelEnt = charmenu.descriptionModel.Entity
				local hairBodygroupID = modelEnt:FindBodygroupByName("facialhair")
				local curValue = modelEnt:GetBodygroup(hairBodygroupID)
				local newValue = math.Clamp(curValue+1,0,modelEnt:GetBodygroupCount(hairBodygroupID)+1)
				modelEnt:SetBodygroup(hairBodygroupID,newValue)
				payload:Set("facialhairbodygroup", newValue)
			end
			plus:SetWidth(container:GetWide()/2)
			plus:SetHeight(height)
			grid:AddItem(plus)
			








			return grid
		end,
		OnValidate = function(self, value, payload, client)
		end,
		OnAdjust = function(self, client, data, value, newData)
            
		end,
		ShouldDisplay = function(self, container, payload)
			return true
		end
	})

	ix.char.RegisterVar("haircolor", {
		field = "haircolor",
		fieldType = ix.type.string,
		default = "255,255,255,255",
		index = 6,
		OnSet = function(character, value)
			local client = character:GetPlayer()

			if (IsValid(client) and client:GetCharacter() == character) then
				//client:ReloadBody()
			end

			character.vars.haircolor = value
		end,
		OnGet = function(character, default)
			return character.vars.haircolor or default
		end,
		OnDisplay = function(self, container, payload)
			payload:Set("haircolor",self.default)

			local charmenu = container:GetParent():GetParent()

			local height = draw.GetFontHeight("ixMenuButtonFont")

			local colorselection = container:Add("DColorCombo")
			colorselection:Dock(TOP)


			colorselection.OnValueChanged = function(newColor,x)
				local color = Color(x.r,x.g,x.b,255)
				charmenu.descriptionModel:SetColor(color)
				payload:Set("haircolor", tostring(color))
				//PrintTable(x)
				

			end
			return colorselection
		end,
		OnValidate = function(self, value, payload, client)
		end,
		OnAdjust = function(self, client, data, value, newData)
            
		end,
		ShouldDisplay = function(self, container, payload)
			return true
		end
	})

