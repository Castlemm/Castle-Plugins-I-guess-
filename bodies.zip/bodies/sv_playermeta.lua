local PLAYER = FindMetaTable("Player")
local customArms = {
	["models/thespireroleplay/humans/group028/male.mdl"] = "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group029/male.mdl"] = "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group030/male.mdl"] = "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group031/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group032/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group033/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group034/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group035/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group036/male.mdl"]= "models/thespireroleplay/humans/group026/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group037/male.mdl"]= "models/thespireroleplay/humans/group026/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group038/male.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/props/ncrmale.mdl"]= "models/thespireroleplay/humans/group027/arms/male_arm.mdl",
	["models/props/ncrfemale.mdl"]= "models/thespireroleplay/humans/group027/arms/ghoul_arm.mdl",
	["models/thespireroleplay/humans/group520/male.mdl"]= "",
	["models/thespireroleplay/humans/group520/female.mdl"]= "",
	["models/thespireroleplay/humans/group522/male.mdl"]= "",
	["models/thespireroleplay/humans/group522/female.mdl"]= "",
	["models/thespireroleplay/humans/group518/armor.mdl"]= "",
	["models/thespireroleplay/humans/group600/armor.mdl"]= "",
	["models/cgcclothing/t45/body.mdl"]= "",
	["models/thespireroleplay/humans/group525/male.mdl"]= "",
	["models/thespireroleplay/humans/group525/female.mdl"]= "",
	["models/thespireroleplay/humans/group300/male.mdl"]= "",
	["models/thespireroleplay/humans/group300/female.mdl"]= "",
	["models/thespireroleplay/humans/group301/male.mdl"]= "",
	["models/thespireroleplay/humans/group301/female.mdl"]= "",
	["models/thespireroleplay/humans/group315/male.mdl"]= "",
	["models/thespireroleplay/humans/group315/female.mdl"]= "",
	["models/thespireroleplay/humans/group199/female.mdl"]= "",
	["models/thespireroleplay/humans/group199/male.mdl"]= "",
	["models/thespireroleplay/humans/group211/male.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group113/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group211/female.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group113/arms/female_arm.mdl",
	["models/thespireroleplay/humans/group204/male.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group113/arms/male_arm.mdl",
	["models/thespireroleplay/humans/group204/female.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group113/arms/female_arm.mdl",
	["models/armors/enclavetrooper2/male.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group115/arms/male_arm.mdl",
	["models/armors/enclavetroopermark2/male.mdl"]= "models/armors/arms/enclave/male_arm.mdl",
	["models/thefrontier/humans/legionlead/male.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group113/arms/male_arm.mdl",
	["models/thefrontier/humans/pelegion/male.mdl"]= "models/lazarusroleplay/thespireroleplay/humans/group114/arms/male_arm.mdl",
	["models/player/yates/bosknightfbody.mdl"]= "",
	["models/player/yates/bosknightbody.mdl"]= "",

}
local faceColors = {
	["african"] = 2,
	["asian"] = 6,
	["hispanic"] = 4,
	["caucasian"] = 0
}
function PLAYER:UpdateHandsSkin()
	local currentHead = self.head:GetModel()
	local toChange = 1
	for k,v in pairs(faceColors) do
		if( string.find(currentHead,k) ) then
			toChange = v 
			break 
		end
	end
	if(IsValid(self.hands)) then
		self.hands:SetSkin(toChange)
	end
end
function PLAYER:ApplyHeadAttributes()

    local character = self:GetCharacter()
    if(!character) then return end
    local hair = character:GetHairbodygroup() or 0
    local beard = character:GetFacialhairbodygroup() or 0
    local haircolor =  string.ToColor(character:GetHaircolor())
    local head = self.head
    head:SetColor(haircolor)
    head:SetBodygroup(head:FindBodygroupByName("hair"),hair)
    head:SetBodygroup(head:FindBodygroupByName("facialhair"),beard)
end

function PLAYER:LoadBody()
    if(self.head or IsValid(self.head)) then //Just reset.
        self.head:Remove()
        self.head = nil
    end
    if(self.body or IsValid(self.body)) then
        self.body:Remove()
        self.body = nil
    end
	if(self.hands) then
        self.hands:Remove()
        self.hands = nil
    end  
    local character = self:GetCharacter()
    self:SetModel(character:GetHeadmodel())
    if(!self.head)then
		self:SetRenderMode(1) //Render mode to handle our transparency to hide default playermodel
		self:SetColor(Color(0, 0, 0, 0))
		self.head = ents.Create("prop_physics")
		self.head:SetModel(character:GetHeadmodel())
		self.head:SetParent(self)
		self.head:AddEffects(EF_BONEMERGE)
    end
    if(!self.body)then
    self:SetRenderMode(1)
    self:SetColor(Color(0, 0, 0, 0))
        self.body = ents.Create("prop_physics")
        self.body:SetModel(character:GetBodymodel())
        self.body:SetParent(self)
        self.body:AddEffects(EF_BONEMERGE)

    end

	//util.IsValidModel( string modelName )
	if(!self.hands)then
		self:SetRenderMode(1)
		self:SetColor(Color(0, 0, 0, 0))
        self.hands = ents.Create("prop_physics")

		local currModel = self.body:GetModel()
		if(customArms[currModel]) then
			self.hands:SetModel(customArms[currModel])
		else
			if(currModel:find("female")) then
				self.hands:SetModel(string.Left(currModel,currModel:find("female")-1 ).."arms/female_arm.mdl")
			else
				print(currModel,string.Replace(currModel,"male", "female_arm"))
				self.hands:SetModel(string.Left(currModel,currModel:find("male")-1 ).."arms/male_arm.mdl")
			end
		end
		self:UpdateHandsSkin()
        self.hands:SetParent(self)
        self.hands:AddEffects(EF_BONEMERGE)
    end
    //print(self.ApplyHeadAttributes)
    self:ApplyHeadAttributes()

end

function PLAYER:SetRagdolled(bState, time, getUpGrace)
		if (!self:Alive()) then
			return
		end

		getUpGrace = getUpGrace or time or 5

		if (bState) then
			if (IsValid(self.ixRagdoll)) then
				self.ixRagdoll:Remove()
			end

			local entity = self:CreateServerRagdoll()

			entity:CallOnRemove("fixer", function()
				if (IsValid(self)) then
					self:SetLocalVar("blur", nil)
					self:SetLocalVar("ragdoll", nil)

					if (!entity.ixNoReset) then
						self:SetPos(entity:GetPos())
					end

					self:SetNoDraw(false)
					self:SetNotSolid(false)
					self:SetMoveType(MOVETYPE_WALK)
					self:SetLocalVelocity(IsValid(entity) and entity.ixLastVelocity or vector_origin)
				end

				if (IsValid(self) and !entity.ixIgnoreDelete) then
					if (entity.ixWeapons) then
						for _, v in ipairs(entity.ixWeapons) do
							if (v.class) then
								local weapon = self:Give(v.class, true)

								if (v.item) then
									weapon.ixItem = v.item
								end

								self:SetAmmo(v.ammo, weapon:GetPrimaryAmmoType())
								weapon:SetClip1(v.clip)
							elseif (v.item and v.invID == v.item.invID) then
								v.item:Equip(self, true, true)
								self:SetAmmo(v.ammo, self.carryWeapons[v.item.weaponCategory]:GetPrimaryAmmoType())
							end
						end
					end

					if (entity.ixActiveWeapon) then
						if (self:HasWeapon(entity.ixActiveWeapon)) then
							self:SetActiveWeapon(self:GetWeapon(entity.ixActiveWeapon))
						else
							local weapons = self:GetWeapons()
							if (#weapons > 0) then
								self:SetActiveWeapon(weapons[1])
							end
						end
					end

					if (self:IsStuck()) then
						entity:DropToFloor()
						self:SetPos(entity:GetPos() + Vector(0, 0, 16))

						local positions = ix.util.FindEmptySpace(self, {entity, self})

						for _, v in ipairs(positions) do
							self:SetPos(v)

							if (!self:IsStuck()) then
								return
							end
						end
					end
				end

			end)

			self:SetLocalVar("blur", 25)
			self.ixRagdoll = entity

			entity.ixWeapons = {}
			entity.ixPlayer = self

			if (getUpGrace) then
				entity.ixGrace = CurTime() + getUpGrace
			end

			if (time and time > 0) then
				entity.ixStart = CurTime()
				entity.ixFinish = entity.ixStart + time

				self:SetAction("@wakingUp", nil, nil, entity.ixStart, entity.ixFinish)
			end

			if (IsValid(self:GetActiveWeapon())) then
				entity.ixActiveWeapon = self:GetActiveWeapon():GetClass()
			end

			for _, v in ipairs(self:GetWeapons()) do
				if (v.ixItem and v.ixItem.Equip and v.ixItem.Unequip) then
					entity.ixWeapons[#entity.ixWeapons + 1] = {
						item = v.ixItem,
						invID = v.ixItem.invID,
						ammo = self:GetAmmoCount(v:GetPrimaryAmmoType())
					}
					v.ixItem:Unequip(self, false)
				else
					local clip = v:Clip1()
					local reserve = self:GetAmmoCount(v:GetPrimaryAmmoType())
					entity.ixWeapons[#entity.ixWeapons + 1] = {
						class = v:GetClass(),
						item = v.ixItem,
						clip = clip,
						ammo = reserve
					}
				end
			end

			self:GodDisable()
			self:StripWeapons()
			self:SetMoveType(MOVETYPE_OBSERVER)
			self:SetNoDraw(true)
			self:SetNotSolid(true)

			local uniqueID = "ixUnRagdoll" .. self:SteamID()

			if (time) then
				timer.Create(uniqueID, 0.33, 0, function()
					if (IsValid(entity) and IsValid(self) and self.ixRagdoll == entity) then
						local velocity = entity:GetVelocity()
						entity.ixLastVelocity = velocity

						self:SetPos(entity:GetPos())

						if (velocity:Length2D() >= 8) then
							if (!entity.ixPausing) then
								self:SetAction()
								entity.ixPausing = true
							end

							return
						elseif (entity.ixPausing) then
							self:SetAction("@wakingUp", time)
							entity.ixPausing = false
						end

						time = time - 0.33

						if (time <= 0) then
							hook.Run("OnCharacterGetup", self, entity)
							print("getup123123123")
							entity:Remove()
						end
					else
						timer.Remove(uniqueID)
					end
				end)
			else
				timer.Create(uniqueID, 0.33, 0, function()
					if (IsValid(entity) and IsValid(self) and self.ixRagdoll == entity) then
						self:SetPos(entity:GetPos())
					else
						timer.Remove(uniqueID)
					end
				end)
			end

			self:SetLocalVar("ragdoll", entity:EntIndex())
			hook.Run("OnCharacterFallover", self, entity, true)
		elseif (IsValid(self.ixRagdoll)) then
			self.ixRagdoll:Remove()

			hook.Run("OnCharacterFallover", self, nil, false)
		end
	
end
