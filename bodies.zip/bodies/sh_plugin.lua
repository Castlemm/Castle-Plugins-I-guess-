PLUGIN.name = "Bodies "
PLUGIN.author = "Castle Edited"
ix.util.Include("sh_charvars.lua") //NEW VARS AND CHAR CREATION HANDLE
ix.util.Include("sh_commands.lua") //Commands for setting head/body model
ix.util.Include("sv_core.lua") //Ragdolls fix, applying body on player after spawn
ix.util.Include("sv_playermeta.lua") //Player Methods, workaround for character getup
ix.util.Include("cl_charcreation.lua") //Fix for showing face instead of default one PlayerModel view
ix.util.Include("cl_charload.lua") //Fix for showing face instead of default one PlayerModel view

ix.flag.Add("P","Ability to wear Power Armor")


if(CLIENT)then
    function PLUGIN:PlayerFootstep()
        return true
    end
end

/*
function PLUGIN:PlayerFootstep(ply)
    local itemTable = ply.footsteps or ply:GetNWString("footstep",false) or false
    if(itemTable) then
        itemTable = ix.item.Get(itemTable)
        local randomSound = itemTable.customFootsteps[math.random(1,#itemTable.customFootsteps)]
        ply:EmitSound(randomSound)
        return true
    end
end*/




