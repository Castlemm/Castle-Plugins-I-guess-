function ApplyBody(entity,client,bApplyHeadAttribs)
    if(client.head) then
        client.head:Remove()
        client.head = nil
    end
    if(client.body) then
        client.body:Remove()
        client.body = nil
    end
    if(client.hands) then
        client.hands:Remove()
        client.hands = nil
    end   
    local character = client:GetCharacter()
    if(!character) then return end
    entity:SetModel(character:GetHeadmodel())
    if(!entity.head)then
    entity:SetRenderMode(1)
    entity:SetColor(Color(0, 0, 0, 0))
        entity.head = ents.Create("prop_physics")
        entity.head:SetModel(character:GetHeadmodel())
        entity.head:SetParent(entity)
        entity.head:AddEffects(EF_BONEMERGE)

        if(entity.head:GetModel():find("ghoul")) then
        entity.hands:SetModel(string.Replace(entity.body:GetModel(),"ghoul", "arms"))
        end
    end



    if(!entity.body)then
    entity:SetRenderMode(1)
    entity:SetColor(Color(0, 0, 0, 0))
        entity.body = ents.Create("prop_physics")
        entity.body:SetModel(character:GetBodymodel())
        entity.body:SetParent(entity)
        entity.body:AddEffects(EF_BONEMERGE)
    end

    if(!entity.hands)then
    entity:SetRenderMode(1)
    entity:SetColor(Color(0, 0, 0, 0))
        entity.hands = ents.Create("prop_physics")
        if(entity.body:GetModel():find("female")) then
            print(entity.body:GetModel(),string.Replace(entity.body:GetModel(),"female", "arms"))
            entity.hands:SetModel(string.Replace(entity.body:GetModel(),"female", "arms"))
        elseif(entity.head:GetModel():find("ghoul")) then
            print(entity.body:GetModel(),string.Replace(entity.body:GetModel(),"ghoul", "arms"))
            entity.hands:SetModel(string.Replace(entity.body:GetModel(),"ghoul", "arms"))
        else
            print(entity.body:GetModel(),string.Replace(entity.body:GetModel(),"male", "arms"))
            entity.hands:SetModel(string.Replace(entity.body:GetModel(),"male", "arms"))
        end
        entity.hands:SetParent(entity)
        entity.hands:AddEffects(EF_BONEMERGE)
    end

    if(bApplyHeadAttribs) then
        local hair = character:GetHairbodygroup()
        local beard = character:GetFacialhairbodygroup()
        local haircolor =  string.ToColor(character:GetHaircolor())
        entity.head:SetColor(haircolor)
        entity.head:SetBodygroup(entity.head:FindBodygroupByName("hair"),hair)
        entity.head:SetBodygroup(entity.head:FindBodygroupByName("facialhair"),beard)
    end
end


function PLUGIN:OnCharacterFallover(client, entity, bFallenOver)
    //print("fallover",bFallenOver)
    if(bFallenOver)then
        ApplyBody(entity,client,true)
    else
        client:LoadBody()
    end
end

function PLUGIN:OnCharacterGetup(client, ragdoll)
    //print("Getup1")
    client:LoadBody()
end


function PLUGIN:PostPlayerLoadout(client)
    client:LoadBody()
end

function PLUGIN:PostPlayerDeath(client)
    local ragdoll = client:GetRagdollEntity()
    if(ragdoll)then
        ApplyBody(ragdoll,client,true)
    end
end


local metalImpact = {
    "physics/metal/metal_barrel_impact_soft1.wav",
"physics/metal/metal_barrel_impact_soft2.wav",
"physics/metal/metal_barrel_impact_soft3.wav",
"physics/metal/metal_barrel_impact_soft4.wav"
}
local metalImpactHard = {
    "physics/metal/metal_barrel_impact_hard1.wav",
    "physics/metal/metal_barrel_impact_hard2.wav",
    "physics/metal/metal_barrel_impact_hard3.wav",
    "physics/metal/metal_barrel_impact_hard5.wav",
    "physics/metal/metal_barrel_impact_hard6.wav",
    "physics/metal/metal_barrel_impact_hard7.wav"    
}
function PLUGIN:EntityTakeDamage(target,dmg )
    if(target:IsPlayer())  then
        local character = target:GetCharacter()
        if(character) then
            if(dmg:GetDamageType()==DMG_FALL) then
                local items = character:GetInventory():GetItems()
                for k,v in pairs(items) do
                    if(v.IsPA and v:GetData("equip",false)) then
                        dmg:SetDamage(0)
                        return 0
                    end
                end
            end
            local dmgAmount = dmg:GetDamage()
            dmg:SetDamage(dmgAmount-dmgAmount*(target.defencePercentage or 0))
            if(target.defencePercentage>=0.5 and ( (target.nextImpactSound or CurTime())<=CurTime() )) then
                if(target.defencePercentage>=0.7) then
                    target:EmitSound(metalImpactHard[math.random(1,#metalImpactHard)])
                else
                    target:EmitSound(metalImpact[math.random(1,#metalImpact)])
                end
                
                target.nextImpactSound = CurTime()+0.3
                //print("Emit Sound")
            end
        end
    end
end



function PLUGIN:PlayerStaminaGained(client)
    local character = client:GetCharacter()
    local inventory = character:GetInventory():GetItems()
    for _,v in pairs(inventory) do
        if( v.base == "base_bodies" and v:GetData("equip")) then
            local client = character:GetPlayer()
            local runSpeed = ix.config.Get("runSpeed")
            client.RunSpeedBody = runSpeed*v.speedModifier
            client:SetRunSpeed(runSpeed*v.speedModifier)
        end
    end
end
function PLUGIN:CharacterLoaded(character)
    local inventory = character:GetInventory():GetItems()
    for _,v in pairs(inventory) do
        if( v.base == "base_bodies" and v:GetData("equip")) then

            local client = character:GetPlayer()
            client.footsteps = v.uniqueID
            //client:SetNWString("footstep",v.uniqueID)

            local runSpeed = ix.config.Get("runSpeed")
            client.RunSpeedBody = runSpeed*v.speedModifier
            timer.Simple(1.2, function()
                client:SetRunSpeed(runSpeed*v.speedModifier)
            end)
            client:SetRunSpeed(runSpeed*v.speedModifier)
            client.defencePercentage = v.defencePercentage
        
        end
    end
end

function PLUGIN:PlayerFootstep(ply, position, foot, soundName, volume)
    local itemTable = ply.footsteps or false
    if(itemTable) then
        itemTable = ix.item.Get(itemTable)
        if(!itemTable.customFootsteps) then return end
        local randomSound = itemTable.customFootsteps[math.random(1,#itemTable.customFootsteps)]
        ply:EmitSound(randomSound)
        return true
    end
    
    ply:EmitSound(soundName)
	return true
end