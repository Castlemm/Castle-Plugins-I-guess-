ITEM.name = "Outfit"
ITEM.description = "A Outfit Base."
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.category = "outfit"
ITEM.maleModel = "models/Gibs/HGIBS.mdl"
ITEM.femaleModel = "models/Gibs/HGIBS.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "model"

ITEM.speedModifier = 1.0
ITEM.defencePercentage = 0
ITEM.isPA = false
ITEM.customFootsteps = false


-- Inventory drawing
if (CLIENT) then
	function ITEM:PaintOver(item, w, h)
		if (item:GetData("equip")) then
			surface.SetDrawColor(110, 255, 110, 100)
			surface.DrawRect(w - 14, h - 14, 8, 8)
		end
	end

	function ITEM:PopulateTooltip(tooltip)
		local panel = tooltip:AddRowAfter("description")
		panel:SetBackgroundColor(derma.GetColor("Warning", tooltip))
		panel:SetText("DT:" .. self.defencePercentage)
		panel:SizeToContents()
		local panel3 = tooltip:AddRowAfter("name", "panel2")
		panel3:SetBackgroundColor(derma.GetColor("Warning", tooltip))
		panel3:SetText(self.category)
		panel3:SizeToContents()
	end
end



function ITEM:RemoveOutfit(client)
	local character = client:GetCharacter()

	self:SetData("equip", false)

	local isFemale = string.find(character:GetHeadmodel(),"female")
	local model = ""
	if(isFemale)then
		character:SetBodymodel("models/thespireroleplay/humans/group100/female.mdl") 
	else
	    character:SetBodymodel("models/thespireroleplay/humans/group100/male.mdl")
	end

	self:OnUnequipped()
end





ITEM:Hook("drop", function(item)
	local character = ix.char.loaded[item.owner]
	local client = character and character:GetPlayer() or item:GetOwner()

	item.player = client

	if (item:GetData("equip")) then
		ix.util.Notify("Unequip to drop this item.", client)
		return false
	else
		item:RemoveOutfit(item:GetOwner())
	end
end)

ITEM.functions.EquipUn = { -- sorry, for name order.
	name = "Unequip",
	tip = "equipTip",
	icon = "icon16/cross.png",
	OnRun = function(item)
		item:RemoveOutfit(item.player)
		ix.chat.Send(item.player, "iteminternal", "un-equips their "..item.name..".", false)
		return false
		
	end,
	OnCanRun = function(item)
		local client = item.player


		return !IsValid(item.entity) and IsValid(client) and item:GetData("equip") == true and
			hook.Run("CanPlayerUnequipItem", client, item) != false
	end
}

ITEM.functions.Equip = {
	name = "Equip",
	tip = "equipTip",
	icon = "icon16/tick.png",
	OnRun = function(item)
		print("equip")
		local client = item.player
		local char = client:GetCharacter()
		local character = char
		local items = char:GetInventory():GetItems()

		ix.chat.Send(item.player, "iteminternal", "equips their "..item.name..".", false)

		for _, v in pairs(items) do
			if (v.id != item.id) then
				local itemTable = ix.item.instances[v.id]

				if(v.outfitCategory == item.outfitCategory and itemTable:GetData("equip")) then
					client:NotifyLocalized(item.equippedNotify or "outfitAlreadyEquipped")
					return false
				end
			end
		end

		item:SetData("equip", true)
        local currentModel = char:GetHeadmodel()
        if(item.maleModel and item.femaleModel) then
            if(string.find(currentModel,"female"))then
                char:SetBodymodel(item.femaleModel)
            else
                char:SetBodymodel(item.maleModel)
            end
        elseif(item.maleModel)then
            char:SetBodymodel(item.maleModel)
        
        elseif(item.femaleModel) then
            char:SetBodymodel(item.femaleModel)
        end
		
		if (item.newSkin) then
			character:SetData("oldSkin" .. item.outfitCategory, client.body:GetSkin())
			client.body:SetSkin(item.newSkin)
		end

		local groups = character:GetData("groups", {})

		-- remove original bodygroups
		if (!table.IsEmpty(groups)) then
			character:SetData("oldGroups" .. item.outfitCategory, groups)
			character:SetData("groups", {})
	
			client.body:ResetBodygroups()
		end

		groups = item:GetData("groups", {})

		-- restore bodygroups saved to the item
		if (!table.IsEmpty(groups) and client.body:ShouldRestoreBodygroups()) then
			for k, v in pairs(groups) do
				client.body:SetBodygroup(k, v)
			end
		-- apply default item bodygroups if none are saved
		elseif (istable(item.bodyGroups)) then
			for k, v in pairs(item.bodyGroups) do
				local index = client.body:FindBodygroupByName(k)
	
				if (index > -1) then
					client.body:SetBodygroup(index, v)
				end
			end
		end

		item:OnEquipped()
		return false
	end,
	OnCanRun = function(item)
		local client = item.player
		local powerarmor = true
		if(item.isPA) then
			if(!(client:GetCharacter():HasFlags("P"))) then
				powerarmor = false
			end
		end
		return !IsValid(item.entity) and IsValid(client) and powerarmor and item:GetData("equip") != true and item:CanEquipOutfit() and
			hook.Run("CanPlayerEquipItem", client, item) != false
	end
}

function ITEM:CanTransfer(oldInventory, newInventory)
	if (self:GetData("equip")) then
		return false
	else
		return true
	end
end

function ITEM:OnRemoved()
	if (self.invID != 0 and self:GetData("equip")) then
		self.player = self:GetOwner()
		self:RemoveOutfit(self.player)
		

		if (self.newSkin) then
			if (character:GetData("oldSkin" .. self.outfitCategory)) then
				self.player.body:SetSkin(character:GetData("oldSkin" .. self.outfitCategory))
				character:SetData("oldSkin" .. self.outfitCategory, nil)
			else
				self.player.body:SetSkin(0)
			end
		end

		local groups = {}

		for i = 0, (self.player.body:GetNumBodyGroups() - 1) do
			local bodygroup = self.player.body:GetBodygroup(i)
	
			if (bodygroup > 0) then
				groups[i] = bodygroup
			end
		end
	
		-- save outfit bodygroups
		if (!table.IsEmpty(groups)) then
			self:SetData("groups", groups)
		end
	
		-- remove outfit bodygroups
		self.player.body:ResetBodygroups()


			-- get character original bodygroups
		groups = character:GetData("oldGroups" .. self.outfitCategory, {})

		-- restore original bodygroups
		if (!table.IsEmpty(groups)) then
			for k, v in pairs(groups) do
				self.player.body:SetBodygroup(k, v)
			end

			character:SetData("groups", character:GetData("oldGroups" .. self.outfitCategory, {}))
			character:SetData("oldGroups" .. self.outfitCategory, nil)
		end
		self.player = nil
	end
end

function ITEM:OnEquipped()
	
	local client = self.player
	local char = client:GetCharacter()


	client:EmitSound("ui/app_on.wav", 75, 100, 0.35)
	client.footsteps = self.uniqueID
	client:SetNWString("footstep",self.uniqueID)

	local runSpeed = ix.config.Get("runSpeed")
	client.RunSpeedBody = runSpeed*self.speedModifier
	client:SetRunSpeed((runSpeed*self.speedModifier))

	client.defencePercentage = self.defencePercentage
end

function ITEM:OnUnequipped()
	local client = self.player
	local char = client:GetCharacter()
	client:EmitSound("ui/app_off.wav", 75, 100, 0.35)
	client.footsteps = false
	client:SetNWString("footstep","false")

	client.RunSpeedBody = ix.config.Get("runSpeed")
	client:SetRunSpeed(ix.config.Get("runSpeed"))	

	client.defencePercentage = 0
end

function ITEM:OnLoadout()
	local client = self.player
	local char = client:GetCharacter()

	if (self:GetData("equip", true)) then 
		client.body:SetSkin(self.newSkin)
		client:EmitSound("ui/app_on.wav", 75, 100, 0.35)
		client.footsteps = self.uniqueID
		client:SetNWString("footstep",self.uniqueID)
		local runSpeed = ix.config.Get("runSpeed")
		client.RunSpeedBody = runSpeed*self.speedModifier
		client:SetRunSpeed((runSpeed*self.speedModifier) + (char:GetAttribute("stm") * 5) )
		client.defencePercentage = self.defencePercentage
	elseif (self:GetData("equip", false)) then
		client:EmitSound("ui/app_off.wav", 75, 100, 0.35)
		client.footsteps = false
		client:SetNWString("footstep","false")
		client.RunSpeedBody = ix.config.Get("runSpeed")
		client:SetRunSpeed(ix.config.Get("runSpeed") + (char:GetAttribute("stm") * 5))	
		client.defencePercentage = 0
	end
end

function ITEM:CanEquipOutfit()
	return true
end

